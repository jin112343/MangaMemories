//
//  MangaMemoriesAppApp.swift
//  MangaMemoriesApp
//
//  Created by mizoi.jin on 2024/10/09.
//

import SwiftUI

@main
struct MangaMemoriesAppApp: App {
    var body: some Scene {
        WindowGroup {
            GalleryView()
        }
    }
}
