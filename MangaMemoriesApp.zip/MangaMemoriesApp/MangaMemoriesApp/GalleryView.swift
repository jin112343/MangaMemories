import SwiftUI

struct GalleryView: View {
    // グリッドレイアウトの設定を保持する配列
    let columns = [
        GridItem(.flexible()), // 1列目のアイテムを柔軟に配置
        GridItem(.flexible())  // 2列目のアイテムを柔軟に配置
    ]

    var body: some View {
        NavigationView { // NavigationViewでラップしてナビゲーションを可能に
            ScrollView { // 全体をスクロール可能にするビュー
                LazyVGrid(columns: columns, spacing: 20) { // グリッド状にアイテムを配置する
                    ForEach(0..<20, id: \ .self) { index in // 0から19までの20個のアイテムを繰り返し生成
                        NavigationLink(destination: DetailView(imageName: "photo"))  { // 画像タップでDetailViewに遷移
                            Image("photo") // システムの「photo」アイコンを表示
                                .resizable() // 画像サイズを変更可能に設定
                                .scaledToFit() // 画像の縦横比を保持して表示
                                .frame(height: 100) // 各画像の高さを100に設定
                        }
                    }
                }
                .padding() // グリッド全体にパディングを設定
            }
            .navigationTitle("ギャラリー") // 画面のタイトルを設定
        }
    }
}

struct GalleryView_Previews: PreviewProvider {
    static var previews: some View {
        GalleryView() // プレビューでGalleryViewを表示
    }
}
