//
//  DetailView.swift
//  MangaMemoriesApp
//
//  Created by mizoi.jin on 2024/10/09.
//

import SwiftUI

struct DetailView: View {
    var imageName: String

    var body: some View {
        VStack {
            Image("photo") // 選択された画像を表示
                .resizable() // 画像サイズを変更可能に設定
                .scaledToFit() // 画像の縦横比を保持して表示
                .padding() // 画像周囲にパディングを追加
            Spacer() // 余白を追加してコンテンツを中央に配置
        }
        .navigationTitle("詳細ビュー") // 詳細画面のタイトルを設定
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(imageName: "photo") // プレビューでDetailViewを表示
    }
}
